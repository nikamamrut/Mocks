package com.example.mocks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
  EditText e1,e2,e3;
   TextView tv;
   Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=findViewById(R.id.editTextAppFullName);
        e2=findViewById(R.id.editTextmobilenumber);
        e3=findViewById(R.id.editTextemail);
        btn=findViewById(R.id.buttonRegister);
        tv=findViewById(R.id.textlogin);
        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,LoginActivity2.class));
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username=e1.getText().toString();
                String mobile=e2.getText().toString();
                String email=e3.getText().toString();
                if(username.length()==0 || mobile.length()==0|| email.length()==0 )
                {
                    Toast.makeText(getApplicationContext(),"please fill all details ",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(getApplicationContext(),"Record inserted succesfully",Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(MainActivity.this,LoginActivity2.class));

                }
            }
        });
    }
}